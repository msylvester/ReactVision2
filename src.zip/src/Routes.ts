export type Routes = {
    PermissionsPage: undefined
    SignUpScreen: undefined
    HomeScreen: undefined
    ProjectScreen: undefined
}