import React, { useState } from 'react';
import {
    View,
    StyleSheet,
    ScrollView,
    Image,
    TouchableOpacity,
    Text
} from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { setImageRedux, updateBlocks } from '../store';
import { useNavigation } from '@react-navigation/native';
import { imageFilenames, imagePaths } from '../filenameConsants';

const LeggoScreen = (props) => {
    const { params: { uid, projectName } } = props.route;
    const navigation = useNavigation();

    const dispatch = useDispatch();
    const project = useSelector((state) => state.user.project);

    const [selectedImage, setSelectedImage] = useState<string | null>(null);

    const handleImageSelect = (filename: string) => {
        setSelectedImage(filename);
    };

    const handlePickSelectedBlock = async () => {
        if (selectedImage) {
            const selectedImage_without_extension = selectedImage.slice(0, -4);

            try {
                await dispatch(updateBlocks(selectedImage_without_extension));
                // Uncomment and adjust the navigation call as needed
                // navigation.navigate('ProjectScreen', { uid, projectName, selectedImage });
            } catch (e) {
                console.error(`Error: ${e}`);
            }
        } else {
            console.log('No image selected');
        }
    };

    return (
        <View style={styles.container}>
            <ScrollView contentContainerStyle={styles.scrollViewContent}>
                <View style={styles.imageGrid}>
                    {imagePaths.map((image, index) => (
                        <TouchableOpacity
                            key={index}
                            onPress={() => handleImageSelect(imageFilenames[index])}
                            style={[
                                styles.imageContainer,
                                selectedImage === imageFilenames[index] && styles.selectedImageContainer,
                            ]}
                        >
                            <Image
                                source={image}
                                style={styles.image}
                            />
                        </TouchableOpacity>
                    ))}
                </View>
            </ScrollView>
            <TouchableOpacity onPress={handlePickSelectedBlock} style={styles.button}>
                <Text style={styles.buttonText}>Pick Selected Block</Text>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    scrollViewContent: {
        flexGrow: 1,
        paddingBottom: 60,
    },
    imageGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'center',
    },
    imageContainer: {
        margin: 5,
        borderWidth: 1,
        borderColor: 'transparent',
    },
    selectedImageContainer: {
        borderColor: 'blue',
    },
    image: {
        width: 100,
        height: 100,
        borderRadius: 5,
    },
    button: {
        position: 'absolute',
        bottom: 20,
        alignSelf: 'center',
        backgroundColor: 'blue',
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderRadius: 5,
    },
    buttonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: 'bold',
    },
});

export default LeggoScreen;
